Arquivo zip gerado em: 18/07/2022 21:11:51 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Proj__1a